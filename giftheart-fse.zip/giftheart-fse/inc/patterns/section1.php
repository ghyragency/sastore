<?php
/**
 * Services Section
 */
return array(
	'title'      => esc_html__( 'Services Section', 'giftheart-fse' ),
	'categories' => array( 'giftheart-fse', 'Services Section' ),
	'content'    => '<!-- wp:group {"style":{"spacing":{"blockGap":"0","padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","right":"var:preset|spacing|50","left":"var:preset|spacing|50"},"margin":{"top":"0","bottom":"0"}}},"backgroundColor":"foreground","layout":{"type":"default"}} -->
<div class="wp-block-group has-foreground-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)"><!-- wp:group {"style":{"spacing":{"blockGap":"0","padding":{"left":"var:preset|spacing|40","right":"var:preset|spacing|40"}}},"layout":{"type":"constrained","contentSize":"1170px"}} -->
<div class="wp-block-group" style="padding-right:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:columns {"style":{"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
<div class="wp-block-columns" style="margin-top:0;margin-bottom:0"><!-- wp:column {"width":"25%","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}},"className":"services-box1"} -->
<div class="wp-block-column services-box1" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;flex-basis:25%"><!-- wp:cover {"url":"'.esc_url(get_template_directory_uri()).'/assets/images/bg-01.jpg","id":354,"dimRatio":0,"minHeight":293,"isDark":false,"style":{"border":{"radius":"15px"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-cover is-light" style="border-radius:15px;min-height:293px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-354" alt="" src="'.esc_url(get_template_directory_uri()).'/assets/images/bg-01.jpg" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:group {"style":{"spacing":{"margin":{"top":"10rem"}}},"className":"services-firstbox","layout":{"type":"constrained"}} -->
<div class="wp-block-group services-firstbox" style="margin-top:10rem"><!-- wp:paragraph {"align":"center","placeholder":"Write title�","style":{"typography":{"fontSize":"18px"},"spacing":{"margin":{"top":"0","bottom":"var:preset|spacing|30","left":"0","right":"0"}}}} -->
<p class="has-text-align-center" style="margin-top:0;margin-right:0;margin-bottom:var(--wp--preset--spacing--30);margin-left:0;font-size:18px">Valentine Day</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center","level":4,"style":{"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
<h4 class="wp-block-heading has-text-align-center" style="margin-top:0;margin-bottom:0">Love Goes On</h4>
<!-- /wp:heading --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"25%","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}},"className":"services-box2"} -->
<div class="wp-block-column services-box2" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;flex-basis:25%"><!-- wp:cover {"url":"'.esc_url(get_template_directory_uri()).'/assets/images/bg-02.jpg","id":367,"dimRatio":0,"minHeight":293,"isDark":false,"style":{"border":{"radius":"15px"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-cover is-light" style="border-radius:15px;min-height:293px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-367" alt="" src="'.esc_url(get_template_directory_uri()).'/assets/images/bg-02.jpg" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"align":"center","placeholder":"Write title�","style":{"typography":{"fontSize":"18px"},"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"}}}} -->
<p class="has-text-align-center" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;font-size:18px">New Collection</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center","level":4,"style":{"spacing":{"margin":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}}} -->
<h4 class="wp-block-heading has-text-align-center" style="margin-top:var(--wp--preset--spacing--30);margin-bottom:var(--wp--preset--spacing--30)">All Occasions</h4>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","placeholder":"Write title�","style":{"typography":{"fontSize":"18px"},"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"}}}} -->
<p class="has-text-align-center" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;font-size:18px"><a href="#">Shop Now</a></p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"50%","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}},"className":"services-box3"} -->
<div class="wp-block-column services-box3" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;flex-basis:50%"><!-- wp:cover {"url":"'.esc_url(get_template_directory_uri()).'/assets/images/bg-03.jpg","id":369,"dimRatio":0,"minHeight":293,"isDark":false,"style":{"border":{"radius":"15px"}},"layout":{"type":"constrained"}} -->
<div class="wp-block-cover is-light" style="border-radius:15px;min-height:293px"><span aria-hidden="true" class="wp-block-cover__background has-background-dim-0 has-background-dim"></span><img class="wp-block-cover__image-background wp-image-369" alt="" src="'.esc_url(get_template_directory_uri()).'/assets/images/bg-03.jpg" data-object-fit="cover"/><div class="wp-block-cover__inner-container"><!-- wp:group {"style":{"spacing":{"padding":{"left":"0rem","right":"50%"},"margin":{"top":"0","bottom":"0"},"blockGap":"var:preset|spacing|50"}},"className":"services-lastbox","layout":{"type":"constrained"}} -->
<div class="wp-block-group services-lastbox" style="margin-top:0;margin-bottom:0;padding-right:50%;padding-left:0rem"><!-- wp:paragraph {"align":"center","placeholder":"Write title�","style":{"typography":{"fontSize":"18px"},"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"}}}} -->
<p class="has-text-align-center" style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;font-size:18px">Christmas Sale</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center","level":4,"style":{"spacing":{"margin":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}}} -->
<h4 class="wp-block-heading has-text-align-center" style="margin-top:var(--wp--preset--spacing--30);margin-bottom:var(--wp--preset--spacing--30)">Up To 40% Off</h4>
<!-- /wp:heading -->

<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons"><!-- wp:button {"textAlign":"center","backgroundColor":"foreground","textColor":"body-text","style":{"elements":{"link":{"color":{"text":"var:preset|color|body-text"}}}}} -->
<div class="wp-block-button"><a class="wp-block-button__link has-body-text-color has-foreground-background-color has-text-color has-background has-link-color has-text-align-center wp-element-button" href="#">View Details</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:group --></div></div>
<!-- /wp:cover --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->',
);