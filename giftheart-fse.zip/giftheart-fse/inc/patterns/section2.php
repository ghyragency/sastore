<?php
/**
 * Welcome to GiftHeart
 */
return array(
	'title'      => esc_html__( 'Welcome to GiftHeart', 'giftheart-fse' ),
	'categories' => array( 'giftheart-fse', 'Welcome to GiftHeart' ),
	'content'    => '<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"0","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}},"color":{"background":"#fbfafa"}},"className":"welcome-section","layout":{"type":"default"}} -->
<div class="wp-block-group welcome-section has-background" style="background-color:#fbfafa;padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:0;padding-left:var(--wp--preset--spacing--50)"><!-- wp:group {"style":{"spacing":{"blockGap":"0","padding":{"left":"var:preset|spacing|40","right":"var:preset|spacing|40"}}},"layout":{"type":"constrained","contentSize":"1170px"}} -->
<div class="wp-block-group" style="padding-right:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--40)"><!-- wp:columns {"style":{"spacing":{"margin":{"top":"0","bottom":"0"},"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}}} -->
<div class="wp-block-columns" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:column {"width":"58%"} -->
<div class="wp-block-column" style="flex-basis:58%"><!-- wp:image {"id":398,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/welcome-gift.jpg" alt="" class="wp-image-398"/></figure>
<!-- /wp:image --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"3%","style":{"spacing":{"padding":{"top":"0","right":"0","bottom":"0","left":"0"},"blockGap":"0"}}} -->
<div class="wp-block-column" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;flex-basis:3%"></div>
<!-- /wp:column -->

<!-- wp:column {"width":"58%","style":{"spacing":{"padding":{"top":"0","right":"0","bottom":"0","left":"0"}}}} -->
<div class="wp-block-column" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;flex-basis:58%"><!-- wp:heading {"textAlign":"left","level":5,"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|30","top":"0"}},"typography":{"fontStyle":"normal","fontWeight":"500","fontSize":"22px"}},"textColor":"primary","fontFamily":"playfair-display"} -->
<h5 class="wp-block-heading has-text-align-left has-primary-color has-text-color has-playfair-display-font-family" style="margin-top:0;margin-bottom:var(--wp--preset--spacing--30);font-size:22px;font-style:normal;font-weight:500">WELCOME TO GIFT HEART</h5>
<!-- /wp:heading -->

<!-- wp:heading {"textAlign":"left","level":3,"style":{"typography":{"fontSize":"46px","fontStyle":"normal","fontWeight":"600","lineHeight":"1.0"},"spacing":{"margin":{"bottom":"var:preset|spacing|60","top":"0","right":"0"}}},"fontFamily":"playfair-display"} -->
<h3 class="wp-block-heading has-text-align-left has-playfair-display-font-family" style="margin-top:0;margin-right:0;margin-bottom:var(--wp--preset--spacing--60);font-size:46px;font-style:normal;font-weight:600;line-height:1.0">Find The Perfect Gift,<br>Every Time!</h3>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"spacing":{"margin":{"right":"0","left":"0","top":"0","bottom":"var:preset|spacing|70"}}}} -->
<p style="margin-top:0;margin-right:0;margin-bottom:var(--wp--preset--spacing--70);margin-left:0">Quisque at porttitor magna. Nam nisi nulla, lobortis non porta sed, pulv<br>inara est. Morbi luctus hendrerit leo, sed facilisis ante dignissi eget. Phas<br>ellus lacus ipsum, cursus et rhoncus nec, dapibus et erat. Cras dictum tel<br>lus sit ametting neque finibus, hendrerit leo, sed facilisis ante dignissi ellus lacus ipsum, cursus et rhoncus nec, dapibus et erat. nec malesuada tell ornare ante dignissi eget.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"style":{"spacing":{"margin":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group" style="margin-top:var(--wp--preset--spacing--70);margin-bottom:var(--wp--preset--spacing--70)"><!-- wp:group {"className":"welcome-list1","layout":{"type":"constrained"}} -->
<div class="wp-block-group welcome-list1"><!-- wp:list {"style":{"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"}},"typography":{"fontStyle":"normal","fontWeight":"500","lineHeight":"1.7","fontSize":"18px"}}} -->
<ul style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;font-size:18px;font-style:normal;font-weight:500;line-height:1.7"><!-- wp:list-item -->
<li>Classic Decorative Gift</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Paper Gift Box</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Stylish Dad Accessory</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"welcome-list2","layout":{"type":"constrained"}} -->
<div class="wp-block-group welcome-list2"><!-- wp:list {"style":{"spacing":{"margin":{"top":"0","bottom":"0","left":"0","right":"0"}},"typography":{"fontStyle":"normal","fontWeight":"500","lineHeight":"1.7","fontSize":"18px"}}} -->
<ul style="margin-top:0;margin-right:0;margin-bottom:0;margin-left:0;font-size:18px;font-style:normal;font-weight:500;line-height:1.7"><!-- wp:list-item -->
<li>Debit/Credit Cards</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Discounted Gift Cards</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Goods &amp; Services</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"backgroundColor":"primary","textColor":"foreground","style":{"spacing":{"padding":{"left":"var:preset|spacing|60","right":"var:preset|spacing|60"}}},"fontSize":"small","fontFamily":"playfair-display"} -->
<div class="wp-block-button has-custom-font-size has-playfair-display-font-family has-small-font-size"><a class="wp-block-button__link has-foreground-color has-primary-background-color has-text-color has-background wp-element-button" href="#" style="padding-right:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--60)">Read More</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->',
);